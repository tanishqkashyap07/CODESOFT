# Titanic Survival Prediction 🚢

A Machine Learning project that predicts the survival of Titanic passengers using **Python**, **scikit-learn**, **XGBoost**, and **SHAP** for explainability.

## 📌 Features
- Data preprocessing & feature engineering
- Random Forest classification model
- SHAP explainability for feature importance
- Modular code with clear structure

## 🗂 Project Structure
```
titanic-survival-prediction/
│
├── data/          # Raw dataset (train.csv, test.csv)
├── outputs/       # Model & plots
├── src/           # Source code
│   ├── utils.py
│   ├── preprocess.py
│   ├── train_model.py
│   └── explain_model.py
├── requirements.txt
└── README.md
```

## 🚀 How to Run
```bash
# Create virtual environment
python -m venv venv
venv\Scripts\activate  # Windows
source venv/bin/activate  # Mac/Linux

# Install dependencies
pip install -r requirements.txt

# Run scripts
python src/preprocess.py
python src/train_model.py
python src/explain_model.py
```

## 📊 Example Output
- Accuracy score
- SHAP summary plot of top features

## 📜 Dataset
Kaggle Titanic Dataset: [https://www.kaggle.com/c/titanic/data](https://www.kaggle.com/c/titanic/data)
