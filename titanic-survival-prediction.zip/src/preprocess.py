import pandas as pd
import numpy as np
from utils import load_data

def preprocess(df):
    df['Sex'] = df['Sex'].map({'male': 0, 'female': 1})
    df['Embarked'] = df['Embarked'].map({'S': 0, 'C': 1, 'Q': 2})
    df['Age'].fillna(df['Age'].median(), inplace=True)
    df['Embarked'].fillna(df['Embarked'].mode()[0], inplace=True)
    df['Fare'].fillna(df['Fare'].median(), inplace=True)
    
    features = ['Pclass', 'Sex', 'Age', 'SibSp', 'Parch', 'Fare', 'Embarked']
    return df[features], df['Survived'] if 'Survived' in df else None

if __name__ == "__main__":
    train_df = load_data("data/train.csv")
    X_train, y_train = preprocess(train_df)
    X_train.to_csv("outputs/X_train.csv", index=False)
    y_train.to_csv("outputs/y_train.csv", index=False)
    print("✅ Data preprocessing completed.")
