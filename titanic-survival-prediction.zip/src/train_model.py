import pandas as pd
import joblib
from utils import split_data
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report

if __name__ == "__main__":
    X = pd.read_csv("outputs/X_train.csv")
    y = pd.read_csv("outputs/y_train.csv").values.ravel()

    X_train, X_test, y_train, y_test = split_data(X, y)

    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"✅ Accuracy: {acc:.4f}")
    print(classification_report(y_test, y_pred))

    joblib.dump(model, "outputs/titanic_model.pkl")
    print("💾 Model saved to outputs/titanic_model.pkl")
