import pandas as pd
import joblib
import shap
import matplotlib.pyplot as plt

if __name__ == "__main__":
    X = pd.read_csv("outputs/X_train.csv")
    model = joblib.load("outputs/titanic_model.pkl")

    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X)

    shap.summary_plot(shap_values[1], X, show=False)
    plt.savefig("outputs/shap_summary.png", bbox_inches='tight')
    print("📊 SHAP summary plot saved to outputs/shap_summary.png")
