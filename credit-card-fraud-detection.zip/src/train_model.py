import pandas as pd
import joblib
from imblearn.over_sampling import SMOTE
from utils import split_data
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix

if __name__ == "__main__":
    X = pd.read_csv("outputs/X.csv")
    y = pd.read_csv("outputs/y.csv").values.ravel()

    sm = SMOTE(random_state=42)
    X_res, y_res = sm.fit_resample(X, y)

    X_train, X_test, y_train, y_test = split_data(X_res, y_res)

    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)
    print("✅ Model training complete.")
    print(classification_report(y_test, y_pred))
    print("Confusion Matrix:")
    print(confusion_matrix(y_test, y_pred))

    joblib.dump(model, "outputs/fraud_model.pkl")
    print("💾 Model saved to outputs/fraud_model.pkl")
