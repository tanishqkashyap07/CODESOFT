import pandas as pd
import joblib
from sklearn.metrics import classification_report, confusion_matrix

if __name__ == "__main__":
    X = pd.read_csv("outputs/X.csv")
    y = pd.read_csv("outputs/y.csv").values.ravel()
    model = joblib.load("outputs/fraud_model.pkl")

    y_pred = model.predict(X)
    print("Classification Report:")
    print(classification_report(y, y_pred))
    print("Confusion Matrix:")
    print(confusion_matrix(y, y_pred))
