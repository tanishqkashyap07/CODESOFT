import pandas as pd
from sklearn.preprocessing import StandardScaler
from utils import load_data

def preprocess(df):
    scaler = StandardScaler()
    df['Amount'] = scaler.fit_transform(df['Amount'].values.reshape(-1, 1))
    X = df.drop(columns=['Class'])
    y = df['Class']
    return X, y

if __name__ == "__main__":
    df = load_data("data/creditcard.csv")
    X, y = preprocess(df)
    X.to_csv("outputs/X.csv", index=False)
    y.to_csv("outputs/y.csv", index=False)
    print("✅ Data preprocessing completed.")
