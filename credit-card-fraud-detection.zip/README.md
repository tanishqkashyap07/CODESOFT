# Credit Card Fraud Detection 💳

A Machine Learning project to detect fraudulent credit card transactions using **Python**, **scikit-learn**, and **imbalanced-learn** for handling imbalanced datasets.

## 📌 Features
- Data preprocessing & scaling
- Logistic Regression / Random Forest classification model
- Handling imbalanced data using SMOTE
- Evaluation using confusion matrix & classification report

## 🗂 Project Structure
```
credit-card-fraud-detection/
│
├── data/          # Raw dataset (creditcard.csv)
├── outputs/       # Model & plots
├── src/           # Source code
│   ├── utils.py
│   ├── preprocess.py
│   ├── train_model.py
│   └── evaluate_model.py
├── requirements.txt
└── README.md
```

## 🚀 How to Run
```bash
# Create virtual environment
python -m venv venv
venv\Scripts\activate  # Windows
source venv/bin/activate  # Mac/Linux

# Install dependencies
pip install -r requirements.txt

# Run scripts
python src/preprocess.py
python src/train_model.py
python src/evaluate_model.py
```

## 📜 Dataset
Kaggle Credit Card Fraud Dataset: [https://www.kaggle.com/mlg-ulb/creditcardfraud](https://www.kaggle.com/mlg-ulb/creditcardfraud)
