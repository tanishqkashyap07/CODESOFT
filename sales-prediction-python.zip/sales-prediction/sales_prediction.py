from src.data_preprocessing import load_data, make_features
from src.model_training import train_model
from src.model_evaluation import evaluate_and_plot

def main():
    print("➡️ Loading data...")
    df = load_data("data/Advertising.csv")
    X, y = make_features(df)

    print("➡️ Training model...")
    model, (X_train, X_test, y_train, y_test) = train_model(X, y)

    print("➡️ Evaluating model...")
    metrics = evaluate_and_plot(model, X_train, X_test, y_train, y_test)

    print("\n✅ Done!")
    print(f"Saved model: models/sales_model.joblib")
    print(f"Plots saved in outputs/: actual_vs_pred.png, residuals_vs_pred.png")

if __name__ == "__main__":
    main()
