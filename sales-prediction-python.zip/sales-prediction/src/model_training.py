from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
import joblib
import os

def train_model(X, y, model_path="models/sales_model.joblib", test_size=0.2, random_state=42):
    numeric_features = list(X.columns)
    preprocessor = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(with_mean=True, with_std=True), numeric_features)
        ],
        remainder="drop"
    )

    model = Pipeline(steps=[
        ("prep", preprocessor),
        ("reg", LinearRegression())
    ])

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )

    model.fit(X_train, y_train)
    os.makedirs(os.path.dirname(model_path), exist_ok=True)
    joblib.dump(model, model_path)
    return model, (X_train, X_test, y_train, y_test)
