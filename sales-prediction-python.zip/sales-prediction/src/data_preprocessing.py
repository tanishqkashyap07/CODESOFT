import os
import pandas as pd

def load_data(path="data/Advertising.csv"):
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Dataset not found at {path}. Please place 'Advertising.csv' in the data/ folder."
        )
    df = pd.read_csv(path)
    df.columns = [c.strip().title() for c in df.columns]
    required = {"Tv", "Radio", "Newspaper", "Sales"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}. Found columns: {list(df.columns)}")
    return df

def make_features(df):
    X = df[["Tv", "Radio", "Newspaper"]].copy()
    y = df["Sales"].astype(float).copy()
    return X, y
