# Sales Prediction using Python (Simple Linear Regression)

Predict **Sales** from advertising spend (TV, Radio, Newspaper) using **Python** and **scikit-learn**.

## ✨ Features
- Clean, human-readable code with comments
- Train/test split + metrics (MAE, MSE, RMSE, R²)
- Residuals and prediction plots
- Saved model (`models/sales_model.joblib`)
- Works with Kaggle Advertising dataset (place `Advertising.csv` in `data/`)

## 📁 Project Structure
```
sales-prediction/
├── README.md
├── requirements.txt
├── sales_prediction.py        # One-click run script
├── sales_prediction.ipynb     # Notebook walkthrough (optional)
│
├── data/
│   └── Advertising.csv        # <-- add this file from Kaggle
│
├── src/
│   ├── data_preprocessing.py
│   ├── model_training.py
│   └── model_evaluation.py
│
├── models/
└── outputs/
```
Dataset source (Kaggle notebook input): https://www.kaggle.com/code/ashydv/sales-prediction-simple-linear-regression/input

## 🚀 Quick Start
```bash
# 1) Create & activate a virtual environment (recommended)
python -m venv venv
# Windows
venv\Scripts\activate
# macOS / Linux
source venv/bin/activate

# 2) Install dependencies
pip install -r requirements.txt

# 3) Add dataset
# Download Advertising.csv from Kaggle and place it into ./data/Advertising.csv

# 4) Run end-to-end
python sales_prediction.py

# (Optional) Run notebook walkthrough
jupyter lab  # or jupyter notebook
open sales_prediction.ipynb
```
